const api = {}
api.install = function (Vue) {
  Vue.prototype.mApi = {
    oldSingerList: `oldSingerList`,
    singerDetail: `singerDetail`,
    singerFance: `singerFance`,
    singerAlbum: `singerAlbum`,
    singerMv: `singerMv`,
    singerList: `singerList`,
    getMvInfo: `getMvInfo`,
    getMvUrl: `getMvUrl`,
    getMvOther: `getMvOther`,
    songLyric: `songLyric`,
    songPlayUrl: `songPlayUrl`,
    albumInfo: `albumInfo`,
    topList: `topList`,
    topListDetail: `topListDetail`,
    songMenuList: `songMenuList`,
    songMenuTags: `songMenuTags`,
    songMenuDetail: 'songMenuDetail',
    homeFocusImage: 'homeFocusImage',
    homeMvList: 'homeMvList'
  }
}
module.exports = api
