const song = {}

song.install = function (Vue) {
  Vue.prototype.mSong = function (item) {
    let obj = {}
    obj.singer = item.singer[0].name
    obj.songid = item.songid
    obj.songmid = item.songmid
    obj.songname = item.songname
    obj.filename = `C400${item.songmid}.m4a`
    obj.songImage = item.albummid
    obj.albumname = item.albumname
    obj.interval = time(item.interval)
    obj.longnumber = item.interval

    function time (interval) {
      let n = Math.floor(interval / 60)
      let m = interval % 60
      if (m < 10) {
        m = '0' + m
      }
      let time = `${n}:${m}`
      return time
    }
    return obj
  }
}
module.exports = song
