
const image = {}
image.install = function (Vue) {
  Vue.prototype.mImg = function (id, t = 1) {
    return `https://y.gtimg.cn/music/photo_new/T00${t}R800x800M000${id}.jpg?max_age=2592000`
  }
}
module.exports = image
