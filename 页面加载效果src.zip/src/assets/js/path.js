const isDev = false
let host
if (isDev) {
  host = 'http://localhost:3000/api_qqmusic'
} else {
  host = 'https://joozh.cn/api_qqmusic'
}

const path = {}
path.install = function (Vue) {
  Vue.prototype.mPath = {
    u: host + '/u_common_url',
    c: host + '/c_common_url'
  }
}
module.exports = path
