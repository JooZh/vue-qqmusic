import Vue from 'vue'
import Router from 'vue-router'

import TabCon from '@/comlayout/TabCon/index'

import Recomment from '@/components/Recomment/index'

import Ranking from '@/components/Ranking/index'
import RankingDetail from '@/components/RankingDetail/index'

import SingerList from '@/components/SingerList/index'
import SingerDetail from '@/components/SingerDetail/index'

import Home from '@/components/Home/index'

import MenuList from '@/components/MenuList/index'
import MenuDetail from '@/components/MenuDetail/index'

Vue.use(Router)

export default new Router({
  mode: 'history',
  scrollBehavior () {
    return { x: 0, y: 0 }
  },
  routes: [{
    path: '/',
    component: TabCon,
    meta: {
      keepAlive: true // 需要缓存
    },
    children: [{
      path: '/',
      component: Recomment,
      meta: {
        keepAlive: true // 需要缓存
      }
    }, {
      path: '/recomment',
      component: Recomment,
      meta: {
        keepAlive: true // 需要缓存
      }
    }, {
      path: '/singer',
      component: SingerList,
      meta: {
        keepAlive: true // 需要缓存
      }
    }, {
      path: '/ranking',
      component: Ranking,
      meta: {
        keepAlive: true // 需要缓存
      }
    }, {
      path: '/menu',
      component: MenuList,
      meta: {
        keepAlive: true // 需要缓存
      }
    }, {
      path: '/home',
      component: Home,
      meta: {
        keepAlive: true // 需要缓存
      }
    }]
  }, {
    path: '/singerdetail',
    component: SingerDetail,
    meta: {
      keepAlive: false // 不需要缓存
    }
  }, {
    path: '/rankingdetail',
    component: RankingDetail,
    meta: {
      keepAlive: false // 不需要缓存
    }
  }, {
    path: '/menudetail',
    component: MenuDetail,
    meta: {
      keepAlive: false // 不需要缓存
    }
  }]
})
