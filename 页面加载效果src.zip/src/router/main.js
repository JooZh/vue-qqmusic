import Vue from 'vue'
import Router from 'vue-router'

import Recomment from '@/components/Recomment/index'

import TopList from '@/components/TopList/index'

import SingerList from '@/components/SingerList/index'
import SingerDetail from '@/components/SingerDetail/index'

import Home from '@/components/Home/index'
import SongMenuList from '@/components/SongMenuList/index'

Vue.use(Router)

export default new Router({
  routes: [{
    path: '/',
    component: BarPage,
    children: [{
        path: ':id',
        component: SingerDetail
      },{
        path: ':id',
        component: SingerDetail
      },{
        path: ':id',
        component: SingerDetail
      },{
        path: ':id',
        component: SingerDetail
      },{
        path: ':id',
        component: SingerDetail
      }
    ]
  }, {
    path: '/recomment',
    component: Recomment
  }, {
    path: '/singer',
    component: SingerList,
    children: [
      {
        path: ':id',
        component: SingerDetail
      }
    ]
  }, {
    path: '/top',
    component: TopList
  }, {
    path: '/menu',
    component: SongMenuList
  }, {
    path: '/home',
    component: Home
  }]
})
