<template>
  <div class="recomment">
    <Header :title="headerTitle" :show="false"></Header>
    <Swiper :items="imageList"></Swiper>
    <div class="hd">精选MV</div>
    <Mvlist :mvlist="mvlist"></Mvlist>
    <!-- <Loading></Loading> -->
  </div>
</template>

<script>
import Header from '@/comlayout/Header/index'
// import Loading from '@/cominclude/Loading/index'
import Swiper from '@/cominclude/Swiper/index'
import Mvlist from '@/comview/MvList/index'

export default {
  beforeRouteEnter (to, from, next) {
    next(vm => {
      document.body.scrollTop = vm.routerScrollTop
      document.documentElement.scrollTop = vm.routerScrollTop
    })
  },
  beforeRouteUpdate (to, from, next) {
    next()
  },
  beforeRouteLeave (to, from, next) {
    this.routerScrollTop = this.scroll
    next()
  },
  props: {
    scroll: {
      type: Number,
      discription: '当前滚动条位置'
    }
  },
  components: {
    Swiper,
    Header,
    // Loading,
    Mvlist
  },
  data () {
    return {
      // 路由使用
      routerScrollTop: 0,
      headerTitle: '推荐',
      imageList: [],
      mvlist: [],
      ready: 0,
      // 滑动控制
      current: 0,
      timer: null,
      startX: 0,
      startY: 0
    }
  },
  mounted () {
    this.getData()
  },
  methods: {
    getData () {
      let mvlist = new Promise(resolve => {
        this.axios.get(this.mPath.c, {
          params: {
            api: this.mApi.homeMvList,
            cmd: 'shoubo',
            lan: 'all'
          }
        }).then(res => {
          let mvListArr = []
          res.data.forEach(item => {
            let s = (item.listennum / 10000).toFixed(2)
            let obj = {
              pic: item.picurl,
              vid: item.vid,
              title: item.mvtitle,
              listenCount: s
            }
            mvListArr.push(obj)
          })
          resolve(mvListArr)
        })
      })
      let imageList = new Promise(resolve => {
        this.axios.get(this.mPath.u, {
          params: {
            api: this.mApi.homeFocusImage
          }
        }).then(res => {
          resolve(res.data)
        })
      })
      Promise.all([mvlist, imageList]).then(values => {
        this.imageList = values[1]
        this.mvlist = values[0]
        this.ready = 1
      })
    }
  }
}
</script>

<style lang="stylus">
  @import '../../assets/css/common'
  .hd
    margin-top 10px
    height 40px
    line-height 40px
    text-align center
    color $themeColor
    font-size $fontM
</style>
