<template>
  <div class="singerlist">
    <Header :title="headerTitle" :show="false"></Header>
    <div class='layout'>
      <div class='areas-fix'>
        <div ref="areascroll" class='areas border-half-bottom'>
          <div ref="areas" class='areas-list'>
            <div class="area" :class="item.id==area?'select':''" @click='areaChange(item.id)' v-for="(item,key) in tags.area" :key="key">
              <span>{{item.name}}</span>
            </div>
          </div>
        </div>
        <div ref="sexscroll" class='areas border-half-bottom'>
          <div ref="sexs" class='areas-list'>
            <div class="area" :class="item.id==sex?'select':''" @click='sexChange(item.id)' v-for="(item,key) in tags.sex" :key="key">
              <span>{{item.name}}</span>
            </div>
          </div>
        </div>
        <div ref="genrescroll" class='areas border-half-bottom'>
          <div ref="genres" class='areas-list'>
            <div class="area" :class="item.id==genre?'select':''" @click='genreChange(item.id)' v-for="(item,key) in tags.genre" :key="key">
              <span>{{item.name}}</span>
            </div>
          </div>
        </div>
      </div>
      <!-- 字母 -->
      <Scroll class='letters border-half-left' :scrollY="true">
        <div class='letters-list'>
          <div class="letter" :class="item.id==letter?'select':''"  @click="letterChange(item.id)" v-for="(item,index) in tags.index" :key="index">
            <span>{{item.name}}</span>
          </div>
        </div>
      </Scroll>
      <!-- 列表 -->
      <div class='singers-lists-main'>
        <div class='singers-list'>
          <div class='singers' v-if="singerlist.length>0">
            <div class='singer' v-for="(item,index) in singerlist" :key="index" @click='openSinger(item.singer_mid,item.singer_name)'>
              <img class='avatar' v-lazy='{src:item.singer_avatar,error:defaultImg,loading:defaultImg}'>
              <div class='info'>
                <div class='name f-name'>{{item.singer_name}}</div>
              </div>
            </div>
          </div>
          <div class='no-singer' v-if="singerlist.length == 0 && loaded">
            <div>
              <div>什么都木有!</div>
              <div>请切换类目继续浏览</div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <Loading v-if="hasMore"></Loading>
  </div>
</template>

<script>
import Header from '@/comlayout/Header/index'
import Loading from '@/cominclude/Loading/index'
import Scroll from '@/cominclude/Scroll/index'
import BScroll from 'better-scroll'

export default {
  components: {
    Header,
    Loading,
    Scroll
  },
  props: {
    scroll: {
      type: Number
    }
  },
  data () {
    return {
      headerTitle: '歌手',
      ready: false,
      hasMore: true,
      loaded: true,
      // 路由使用
      routerScrollTop: 0,
      scrollTop: 0,
      height: 0,
      singerlist: [],
      tags: {},
      init: true,
      letter: -100,
      area: -100,
      genre: -100,
      sex: -100,
      sin: 0,
      page: 1,
      defaultImg: require('@/assets/images/singer.png')
    }
  },
  mounted () {
    this.getData()
  },
  watch: {
    scroll (val) {
      this.scrollTop = val
      if (window.innerHeight + val === this.height) {
        let timer = setTimeout(() => {
          this.getData()
          clearTimeout(timer)
        }, 300)
      }
    }
  },
  methods: {
    openSinger (mid, name) {
      this.$router.push({
        path: `/singerdetail`,
        query: { mid: mid, name: name }
      })
    },
    // 点击切换类目 重置 各种数据
    sexChange (id) {
      this.changeSetData(id, 'sex')
    },
    genreChange (id) {
      this.changeSetData(id, 'genre')
    },
    letterChange (id) {
      this.changeSetData(id, 'letter')
    },
    areaChange (id) {
      this.changeSetData(id, 'area')
    },
    changeSetData (id, str) {
      if (id === this[str]) {
        return false
      }
      this.hasMore = true
      this.scrollTop = 0
      this.singerlist = []
      this[str] = id
      this.sin = 0
      this.cur_page = 1
      this.getData()
    },
    initScroll (fh, ch) {
      let areaList = this.$refs[ch].children
      let width = 0
      Array.from(areaList).forEach((item) => {
        width += item.getBoundingClientRect().width
      })
      this.$refs[ch].style.width = `${width}px`
      this.$nextTick(() => {
        /* eslint-disable no-new */
        new BScroll(this.$refs[fh], {
          scrollX: true,
          click: true
        })
      })
    },
    // 获取数据
    getData () {
      if (!this.hasMore) {
        return
      }
      if (!this.loaded) {
        return
      }
      this.loaded = false
      this.axios.get(this.mPath.u, {
        params: {
          api: this.mApi.singerList,
          param: {
            area: this.area,
            sex: this.sex,
            genre: this.genre,
            index: this.letter,
            sin: this.sin,
            cur_page: this.page
          }
        }
      }).then((res) => {
        // console.log(res.data)
        let singerarr = res.data.singerlist
        // 小程序不支持webp图片
        singerarr.forEach((item, index) => {
          item.singer_avatar = this.mImg(item.singer_mid, 1)
        })
        // 判断当前读取的数据是否存在或者小于包含条数
        let hasMore = true
        if (!singerarr.length || singerarr.length < 80) {
          hasMore = false
        }
        // 合并数组
        let addSingerlist = this.singerlist
        let singerlist = addSingerlist.concat(singerarr)
        // 第一次的时候处理标签
        if (this.page === 1) {
          let tags = res.data.tags
          tags.index[0].name = '热'
          this.tags = tags
        }
        this.singerlist = singerlist
        this.sin = this.sin + 80
        this.page = this.page + 1
        this.ready = true
        this.hasMore = hasMore
        this.loaded = true
        // 每次数据获取完成后调用 获取页面高度
        let timer = setTimeout(() => {
          this.height = document.body.clientHeight
          clearTimeout(timer)
        }, 1000)
        if (this.init) {
          let timer = setTimeout(() => {
            this.initScroll('genrescroll', 'genres')
            this.initScroll('areascroll', 'areas')
            this.initScroll('sexscroll', 'sexs')
            clearTimeout(timer)
            this.init = false
          }, 30)
        }
      })
    }
  },
  // 路由守卫
  beforeRouteEnter (to, from, next) {
    next(vm => {
      document.body.scrollTop = vm.thisScrollTop
      document.documentElement.scrollTop = vm.thisScrollTop
    })
  },
  // routeEnter (to, from, next) {

  // },
  beforeRouteUpdate (to, from, next) {
    next()
  },
  beforeRouteLeave (to, from, next) {
    this.init = true
    this.thisScrollTop = this.scrollTop
    next()
  }
}
</script>

<style lang="stylus">
  @import '../../assets/css/common';
.layout{
  padding:92px 0 0 0
}
.areas-fix{
  position: fixed;
  top:40px;
  left: 0;
  right: 30px;
  background $bgColor
}
.areas-fix .areas{
    overflow: hidden;
    white-space:nowrap;
    position relative
}
.areas-fix .areas-list{
  height: 30px;
  line-height: 30px;
}
.areas-fix .areas .area{
  font-size: 13px;
  padding: 0 7px 0 10px;
  color: #999;
  display: inline-block
}
.areas-fix .areas .area.select{
  color: #ffcd32;
}

.singers-lists-main{
  background: transparent;
  // position: relative;
  // top: 184px;
  // left: 6px;
  // right:30px;
  // bottom:0;
  // overflow: hidden;
}
.singers-lists-main .singers-list{
  height: 100%;
}
.singers-lists-main .singers-list .singers{
  padding-bottom: 10px;
}
.singers-lists-main .singers-list .singer{
  padding: 15px 0 0 25px;
  font-size: 12px;
  display: flex;
}
.singers-lists-main .singers-list .singer .avatar{
  width: 50px;
  height: 50px;
  border-radius: 50%;
  display: block;
  background: #ddd;
}
.singers-lists-main .singers-list .singer .info{
  margin: 0 0 0 15px;
}
.singers-lists-main .singers-list .singer .info .name{
  line-height: 40px;
}
.singers-lists-main .singers-list .singer .info .f-name{
  color: rgba(255,255,255,0.7);
}
.no-singer{
  width: 100%;
  height: 100%;
  color: #999;
  font-size: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
}

.letters{
  width: 30px;
  font-size: 12px;
  font-weight: 700;
  text-align: center;
  position: fixed;
  right: 0;
  top: 40px;
  bottom: 50px;
  z-index: 3;
  background $bgColor
}
.letters .letter{
  width: 30px;
  height: 30px;
  line-height: 30px;
  overflow: hidden;
  color: #999
}
.letters .letter.select{
  color: #ffcd32
}
</style>
