<template>
    <transition name="slide">
      <div class="container">
        <Header :title="showTitle" :show="true" :bg="headerBg"></Header>
        <div id='infos' class='infos'>
          <div class='singer-bg'>
            <img class='background' v-lazy='{src:topInfo.logo,error:defaultImg,loading:defaultImg}'>
          </div>
          <div class='info-content'>
            <img class='min-avatar' v-lazy='{src:topInfo.logo,error:defaultImg,loading:defaultImg}'>
            <div class='info'>
              <div class='name'>{{topInfo.dissname}}</div>
              <div class='fans'>{{topInfo.nickname}}</div>
              <div class='fans'>播放: {{topInfo.visitnum}}</div>
            </div>
          </div>
        </div>
        <div ref="tab" class='tab border-half-bottom'>
          <div class="tab-list" :class="{'fixed':fixed}">
            <div class="tab-list-item left">
              <span class="left">歌单共 {{topInfo.songnum}} 首</span>
            </div>
            <div class="tab-list-item right">
              <span class="right" @click='handlePlayAll'>全部播放</span>
            </div>
          </div>
        </div>
        <SongList :musicList="songlist"></SongList>
      </div>
    </transition>
</template>

<script>
import Header from '@/comlayout/Header/index'
import SongList from '@/comview/SongList/index'
import { mapMutations } from 'vuex'
export default {
  name: 'no-keep',
  components: {
    Header,
    SongList
  },
  props: {
    scroll: {
      type: Number,
      discription: '当前滚动条位置'
    }
  },
  data () {
    return {
      tabTop: 100,
      headerBg: false,
      showTitle: '',
      headerTitle: '',

      disstid: -1,
      fixed: false,
      songlist: [],
      topInfo: {},
      defaultImg: require('@/assets/images/album.png')
    }
  },
  mounted () {
    // 获取参数
    this.disstid = this.$route.query.id
    this.headerTitle = this.$route.query.title
    // 返回顶部
    document.body.scrollTop = 0
    document.documentElement.scrollTop = 0
    // 获取当前页面高度
    this.getMusicList()
  },
  watch: {
    scroll: {
      handler (val, oldName) {
        if (this.tabTop <= val) {
          this.showTitle = this.headerTitle
          this.fixed = true
          this.headerBg = true
        } else {
          this.showTitle = ''
          this.fixed = false
          this.headerBg = false
        }
      }
    }
  },
  methods: {
    handlePlayAll () {
      this.playAll(this.songlist)
      let timer = setTimeout(() => {
        this.audio = document.getElementById('audio')
        this.audio.play()
        clearTimeout(timer)
      }, 100)
    },
    ...mapMutations([
      'playAll'
    ]),
    back () {
      this.$router.go(-1)
    },
    // 获取单曲数据
    getMusicList () {
      this.axios.get(this.mPath.c, {
        params: {
          api: this.mApi.songMenuDetail,
          disstid: this.disstid,
          type: 1,
          json: 1,
          utf8: 1,
          onlysong: 0
        }
      }).then((res) => {
        this.topInfo = res.data.topInfo
        this.songlist = this.musicHander(res.data.songlist)
        // 吸顶效果
        this.tabTop = this.$refs.tab.getBoundingClientRect().top - 40
      })
    },
    // 单曲数据处理
    musicHander (list) {
      let musicList = []
      list.forEach((item, index) => {
        musicList.push(this.mSong(item))
      })
      return musicList
    }
  }

}
</script>

<style lang="stylus" scoped>
@import '../../assets/css/common'
.container
  padding 40px 0 10px 0
  position relative
  background $bgColor
  z-index 10

.infos{
  height: 180px;
  width: 100%;
  position relative
}
.infos .singer-bg{
  background: #353535;
  height: 100%;
  -webkit-filter: blur(30px);
  filter: blur(30px);
  opacity: 0.4;
}
.infos .singer-bg .background{
  width: 100%;
  height: 100%;
}
.infos .info-content{
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  color: #ccc;
}
.infos .info-content .min-avatar{
  width: 120px;
  height: 120px;
  flex: 0 0 120px;
  margin: 25px 20px 25px 30px;
  background: #353535;
}
.infos .info-content .info{
  display: inline-block;
  margin: 25px 20px 0 0;
  flex: 1;
  height: 100px;
}
.infos .info-content .info .name{
  font-size: 18px;
  line-height: 1.2;
  padding: 10px 0;
  overflow: hidden;
  color: #ffcd32;
}
.infos .info-content .info .fans{
  font-size: 14px;
  line-height: 1.5
}

/* 导航 */
.tab{
  width: 100%;
  height 40px
  position: relative;

}
.tab .fixed{
  position: fixed;
  top: 40px;
  left: 0;
  z-index: 2;
  background: #252525;
  transition: background 0.5s ease;
}
.tab-list {
  background: transparent;
  transition: background 0.5s ease;
  width: 100%;
  display: flex;
  line-height: 40px;
  position: absolute;
  top: 0;
  left: 0
}
.tab-list .tab-list-item {
  font-size: 15px;
  font-weight 700
  flex: 1;
  // color: #ffcd32;
  color: rgba(255,255,255,0.5);
}
.tab-list .tab-list-item span{
  padding: 0 15px;
}
.tab-list .tab-list-item.left {
  text-align: left;
}
.tab-list .tab-list-item.right {
  text-align: right
}

.slide-enter-active
// .slide-leave-active
  opacity 1
  transition all 0.5s cubic-bezier(0.075, 0.82, 0.165, 1)
.slide-enter
// .slide-leave-to
  opacity 0
  // left 100%
  transform translate3d(100%, 0, 0)
</style>
