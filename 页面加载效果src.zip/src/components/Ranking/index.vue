<template>
  <div class="ranking">
    <Header :title="headerTitle" :show="false"></Header>
    <div ref="scroll" class="scroll">
      <div class="container">
        <div class='list' v-for="(item,index) in toplist" :key="index" @click='goDetail(item.id,item.topTitle)'>
          <div class='img'>
            <img :src="item.picUrl">
          </div>
          <div class='info'>
            <div class='title'>{{item.topTitle}}</div>
            <div class='name-list' v-for="(value,key) in item.songList" :key="key">
              <span class='color-h'>{{key+1}}</span> {{value.songname}} <span class='color-h'> - {{value.singername}}</span>
            </div>
          </div>
          <div class='right'>
            <div class='v'></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Header from '@/comlayout/Header/index'
import BScroll from 'better-scroll'
export default {
  prpops: {
    scroll: {
      type: Number
    }
  },
  components: {
    Header
  },
  data () {
    return {
      Scroll: null,
      thisScrollTop: 0,
      scrollTop: 0,
      height: 0,
      headerTitle: '排行榜',
      toplist: []
    }
  },
  mounted () {
    this.getData()
  },
  watch: {
    scroll (val) {
      console.log(val)
      this.scrollTop = val
    }
  },
  methods: {
    initScroll () {
      this.Scroll = new BScroll(this.$refs.scroll, {
        scrollY: true,
        click: true
      })
    },
    goDetail (id, title) {
      this.$router.push({
        path: `/rankingdetail`,
        query: {id: id, title: title}
      })
    },
    getData () {
      this.axios.get(this.mPath.c, {
        params: {
          api: this.mApi.topList,
          platform: 'h5',
          needNewCode: 1
        }
      }).then((res) => {
        this.toplist = res.data
        let timer = setTimeout(() => {
          if (this.Scroll) {
            this.Scroll.refresh()
          } else {
            this.initScroll()
          }
          clearTimeout(timer)
        }, 30)
        // let timer = setTimeout(() => {
        //   this.height = document.body.clientHeight
        //   clearTimeout(timer)
        // }, 1000)
      })
    }
  },
  // 路由守卫
  beforeRouteEnter (to, from, next) {
    next(vm => {
      document.body.scrollTop = vm.thisScrollTop
      document.documentElement.scrollTop = vm.thisScrollTop
    })
  },
  beforeRouteUpdate (to, from, next) {
    next()
  },
  beforeRouteLeave (to, from, next) {
    this.thisScrollTop = this.scrollTop
    next()
  }
}
</script>

<style lang="stylus" scoped>
.ranking
  position relative
  width 100%
  height 100%
  .scroll
    position absolute
    top 40px
    left 0
    right 0
    bottom 50px
    width 100%
    overflow hidden
    .container
      padding: 10px 5px 0 5px
      .list
        margin: 0 5px 10px 5px
        display: flex;
        background: #303030
        .img
          flex: 120px 0 0
          img
            width: 100%
            height: 100%
            display: block
        .info
          flex: 1
          margin-left: 10px
          .title
            font-size: 16px
            padding-top 5px
            line-height: 30px
            color: rgba(255,205,50,0.7)
          .name-list
            line-height: 25px;
            height: 25px;
            overflow: hidden;
            font-size: 14px;
            color #ccc
            .color-h
              color: #777;
              font-family: "hiragino sans gb",arial;
        .right
          flex: 30px 0 0;
          display: flex;
          justify-content: center;
          align-items: center
          .v
            display: inline-block;
            border-top: 1px solid #777;
            border-right: 1px solid #777;
            transform: rotate(45deg);
            width: 10px;
            height: 10px
</style>
