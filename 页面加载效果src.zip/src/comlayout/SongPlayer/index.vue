<template>
  <div id="song-player">
    <div class="player" v-show="playerState">
      <div class="play-title border-half-bottom">
        <div class="back-btn">
          <Icon type="ios-arrow-back" />
        </div>
        <div class="title">
          <div class="song-name">
            <div class="pix">{{playSongName}}</div>
          </div>
          <div class="singer-name">
            <div class="pix">{{playSongSinger}}</div>
          </div>
        </div>
        <div class="show-cd" @click="togglePlayer"><Icon type="ios-disc"/></div>
      </div>
      <div class='play-bg'>
        <img class='background' :src='playSongImage' :onerror="defaultImg">
      </div>
      <div class='play-center'>
        <div class="circle" @click="toggleLyric" :class="{'toggleShow':playLyricShow,'toggleHide':!playLyricShow}">
          <img class="cd" :class="{'paused':!playStatus}" :src='playSongImage' :onerror="defaultImg">
        </div>
        <div
          ref="lyric"
          @click="toggleLyric"
          class="lyric"
          :class="{'center': playLyric.length == 1,'toggleShow':!playLyricShow,'toggleHide':playLyricShow}">
          <ul>
            <li
              class="list"
              ref="lyricLine"
              :class="{'current':index == playLyricCurrent}"
              v-for="(item,index) in playLyric"
              :key="index">{{item.text}}</li>
          </ul>
        </div>
      </div>
      <div class='play-bottom'>
        <div class='play-progress'>
          <div class='this-time'>{{playCurrentTime}}</div>
          <div class='progress-box'>
              <Progress :bufferPercent="bufferPercent" :percent="playPercent" @percentChange="onPercentChange" @percentStart="onPercentStart" @percentEnd="onPercentEnd"></Progress>
          </div>
          <div class='all-time'>{{playInterval}}</div>
        </div>
        <div class='play-buttons'>
          <div class='button'>
            <div class='ls-btn'><Icon type="md-shuffle" /></div>
          </div>
          <div class='button'>
            <div class='ls-btn' @click='handlePrev'><Icon type="md-skip-backward" /></div>
          </div>
          <div class='button'>
            <div class='cltr'>
              <div class='play' v-show="!playStatus" @click='handlePlay'><Icon type="md-play" /></div>
              <div class='pause' v-show="playStatus" @click='handlePause'><Icon type="md-pause" /></div>
            </div>
          </div>
          <div class='button'>
            <div class='ls-btn' @click='handleNext'><Icon type="md-skip-forward" /></div>
          </div>
          <div class='button'>
            <div class='ls-btn' @click='togglePlayList'><Icon type="md-list" /></div>
          </div>
        </div>
      </div>
      <div class="play-list" :class="{'list-show':openList}">
        <div class="play-list-bg"></div>
        <div class='play-list-container'>
          <div class='play-list-nav border-half-bottom'>
            <div class='nav-state'>单曲循环 [{{playerList.length}}]</div>
            <div class='nav-center'></div>
            <div class='nav-clear'><Icon class="icon" type="md-trash" /> 清空</div>
          </div>
          <PlayList  class='play-list-scroll'></PlayList>
          <div class='close border-half-top' @click='togglePlayList'><Icon type="ios-arrow-down" /></div>
        </div>
      </div>
    </div>
    <audio id='audio' ref="audio" :src="playSongUrl"></audio>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import Progress from '@/cominclude/Progress/index'
import PlayList from '@/comview/PlayList/index'

import BScroll from 'better-scroll'

export default {
  components: {
    Progress,
    PlayList
  },
  data () {
    return {
      openList: false,
      playLyricShow: true,
      playPercent: 0,
      playSongName: '暂无歌曲',
      playSongSinger: '暂无',
      playSongImage: require('@/assets/images/album.png'),
      playSongUrl: '',
      playSongid: -1,
      playLyric: [{text: '暂无歌词'}],
      playInterval: '0.00',
      playCurrentTime: '0.00',
      playLyricCurrent: 0,
      playSongLong: 0,
      audio: null,
      scroll: null,
      defaultImg: require('@/assets/images/album.png'),
      bufferPercent: 0
    }
  },
  mounted () {
    // 获得 audio 对象
    this.audio = this.$refs.audio
    // 监听播放事件
    this.listenPlayMove()
    // 监听播放结束事件
    this.listenPlayEnd()
  },
  watch: {
    // 显示和隐藏播放器
    playerState (val) {
      if (val) {
        document.body.className = 'fixed'
      } else {
        document.body.className = 'auto'
      }
    },
    // 监听当前播放的歌曲
    playSong (song) {
      this.playSongName = song.songname
      this.playSongSinger = song.singer
      this.playInterval = song.interval
      this.playSongLong = song.longnumber
      this.bufferPercent = 0
      //
      this.getPlaySong(song)

      // 替代 this.$nextTick()
      setTimeout(() => {
        this.audio = this.$refs.audio
        this.play()
        this.audio.play()
      }, 100)
    }
  },
  computed: {
    ...mapGetters([
      'playerState',
      'playSong',
      'playStatus',
      'playerList'
    ])
  },
  methods: {
    // 显示播放列表
    togglePlayList () {
      this.openList = !this.openList
    },

    // 切换cd 和歌词
    toggleLyric () {
      this.playLyricShow = !this.playLyricShow
    },
    // 播放状态切换
    handlePlay () {
      this.play()
      this.audio.play()
    },
    handlePause () {
      this.pause()
      this.audio.pause()
    },
    // 点击下一曲
    handleNext () {
      this.pause()
      this.next()
    },
    handlePrev () {
      this.pause()
      this.prev()
    },
    // 监听播放中
    listenPlayMove () {
      this.audio.ontimeupdate = () => {
        // 监听音频缓存
        let timeRanges = this.audio.buffered
        let timeBuffered = timeRanges.end(timeRanges.length - 1)
        let bufferPercent = (timeBuffered / this.playSongLong).toFixed(0)
        if (this.bufferPercent !== 1) {
          console.log(bufferPercent)
          this.bufferPercent = Number(bufferPercent)
        }
        // 取得对应的歌词时间格式
        let formatTime = this.audio.currentTime.toFixed(0)
        let lyricTime = (this.audio.currentTime * 1000).toFixed(0)
        // 修改数据
        this.playCurrentTime = this.formatTime(formatTime)
        this.playLyricCurrent = this.lyricTime(lyricTime)
        this.playPercent = Number(formatTime / this.playSongLong)
      }
    },
    // 监听播放结束
    listenPlayEnd () {
      this.audio.onended = () => {
        this.handleNext()
      }
    },
    // 滚动歌词
    scrollLyric (n) {
      // 去除实时滚动监听，方便滑动歌词
      if (this.playLyricCurrent === n) {
        return
      }
      if (n > 6) {
        let line = this.$refs.lyricLine[n - 6]
        this.scroll.scrollToElement(line, 1000)
      } else {
        this.scroll.scrollTo(0, 0, 1000)
      }
    },
    // 取得当前播放的歌词索引
    lyricTime (time) {
      let number = this.playLyric.filter(item => time >= item.time).length - 1
      this.scrollLyric(number)
      return number
    },
    // 监听开始拖动进度条
    onPercentStart () {
      this.pause()
      this.audio.pause()
    },
    // 监听拖动中
    onPercentChange (percent) {
      let currentTime = this.playSongLong * percent
      this.playCurrentTime = this.formatTime(currentTime.toFixed(0))
      this.audio.currentTime = currentTime
    },
    // 监听拖动后
    onPercentEnd () {
      this.play()
      this.audio.play()
    },
    // 进度格式时间
    formatTime (time) {
      let n = 0
      let m = 0
      let s = time % 60
      if (time < 10) {
        n = 0
        m = `0${time}`
      } else if (time < 60) {
        n = 0
        m = time
      } else {
        n = Math.floor(time / 60)
        m = s < 10 ? `0${s}` : s
      }
      return `${n}:${m}`
    },
    // 歌词滚动盒子 采用了 better-scroll
    initScroll (lyric) {
      this.$nextTick(() => {
        /* eslint-disable no-new */
        this.scroll = new BScroll(this.$refs.lyric, {
          scrollY: true,
          click: true
        })
      })
    },
    // 获取播放数据
    getPlaySong (song) {
      // 获取播放链接
      let playUrl = new Promise(resolve => {
        this.axios.get(this.mPath.c, {
          params: {
            api: this.mApi.songPlayUrl,
            cid: 205361747,
            songmid: song.songmid,
            filename: song.filename,
            guid: 9449044610
          }
        }).then((res) => {
          resolve(res.data.url)
        })
      })
      // 获取歌词
      let playLyric = new Promise(resolve => {
        this.axios.get(this.mPath.c, {
          params: {
            api: this.mApi.songLyric,
            songmid: song.songmid
          }
        }).then((res) => {
          resolve(res.data.lines)
        })
      })
      // 获取图片
      let playImage = new Promise(resolve => {
        resolve(this.mImg(song.songImage, 2))
      })
      // 保存数据
      Promise.all([playUrl, playLyric, playImage]).then((values) => {
        this.playSongUrl = values[0]
        this.playLyric = values[1]
        this.playSongImage = values[2]
        if (this.scroll) {
          this.scroll.refresh()
        } else {
          this.initScroll()
        }
      })
    },
    // 提交动作
    ...mapActions([
      'togglePlayer',
      'next',
      'prev',
      'play',
      'pause'
    ])
  }
}
</script>

<style lang="stylus" scoped>
@import './index.styl'
</style>
