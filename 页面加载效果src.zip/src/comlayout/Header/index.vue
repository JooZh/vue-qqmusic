<template>
  <header id="header" :class="{'bg':bg,'border-half-bottom':bg}">
    <div class="back-btn">
      <Icon v-if="!show" type="md-search" />
      <Icon v-if="show" type="ios-arrow-back" @click="back"/>
    </div>
    <div class="title">{{title}}</div>
    <div class="show-cd" @click="togglePlayer">
      <Music :play="playStatus"></Music>
    </div>
  </header>
</template>

<script>
import Music from '@/cominclude/Music/index'
import { mapActions, mapGetters } from 'vuex'
export default {
  props: {
    title: {
      type: String,
      default: '标题'
    },
    show: {
      type: Boolean,
      default: true
    },
    bg: {
      type: Boolean,
      default: true
    }
  },
  components: {
    Music
  },
  computed: {
    ...mapGetters(['playStatus'])
  },
  methods: {
    ...mapActions([
      'togglePlayer'
    ]),
    back () {
      this.$router.go(-1)
    }
  }
}
</script>

<style lang="stylus">
  @import '../../assets/css/common';
  #header
    display flex
    height 40px
    font-size $fontM
    line-height 40px
    text-align center
    color $themeColor
    width 100%
    position fixed
    top 0
    left 0
    right 0
    z-index 9
    &.bg
      background $bgColor
    .title
      flex 1
      text-align center
    .back-btn
      flex 40px 0 0
      font-size 28px
      text-align center
      &.hide
        visibility hidden
    .show-cd
      flex 40px 0 0
      font-size 20px
      text-align center
      display flex
      justify-content center
      align-items center
      .pi
        width 30px
        height 30px
        border-radius: 50%
        border 1px solid $themeColor
        display flex
        justify-content center
        align-items center
</style>
