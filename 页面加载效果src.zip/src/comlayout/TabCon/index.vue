<template>
  <!-- <transition name="slide"> -->
    <div id="tab-con">
      <keep-alive>
        <router-view :scroll="scroll"/>
      </keep-alive>
    </div>
  <!-- </transition> -->
</template>

<script>
// import { mapActions, mapGetters } from 'vuex'
export default {
  props: {
    scroll: {
      type: Number,
      discription: '当前滚动条位置'
    }
  },
  data () {
    return {
    }
  },
  mounted () {
  },
  computed: {
    // ...mapGetters([
    //   'count'
    // ])
  },
  methods: {

    // ...mapActions([
    //   'add',
    //   'scroll'
    // ])
  }
  // beforeRouteEnter (to, from, next) {
  //   next(vm => {
  //     document.body.scrollTop = vm.routerScrollTop
  //     document.documentElement.scrollTop = vm.routerScrollTop
  //   })
  // }
}
</script>

<style lang="stylus" scoped>
#tab-con
  color #fff
  position relative
</style>
