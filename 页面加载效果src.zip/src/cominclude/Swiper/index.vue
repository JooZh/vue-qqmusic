<template>
  <div id="swiper" @touchstart="swiperTouchStr($event)" @touchend="swiperTouchEnd($event)">
    <div class="img"><img :src="items[0]" alt=""></div>
    <div class="swiper-item" v-for="(value, index) in items" :key="index" :style="{ transform: `translate3d(${index-current}00%,0,0)`}">
      <img :src="value" alt="">
    </div>
    <div class="dots">
      <div class="dot" v-for="(value,index) in items" :class="current==index?'active':''" :key="index"></div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    items: {
      type: Array
    }
  },
  data () {
    return {
      current: 0,
      timer: null,
      startX: 0,
      startY: 0
    }
  },
  mounted () {
    this.swiper()
  },
  methods: {
    swiper () {
      this.timer = setInterval(() => {
        if (this.current < this.items.length - 1) {
          this.current += 1
        } else {
          this.current = 0
        }
      }, 3000)
    },
    swiperTouchStr (e) {
      clearInterval(this.timer)
      this.startX = e.changedTouches[0].pageX
      this.startY = e.changedTouches[0].pageY
    },
    swiperTouchEnd (e) {
      let x = e.changedTouches[0].pageX - this.startX
      let y = e.changedTouches[0].pageY - this.startY
      if (Math.abs(x) > Math.abs(y) && x > 0) {
        console.log('右滑')
        if (this.current === 0) {
          this.current = this.items.length - 1
        } else {
          this.current -= 1
        }
      } else if (Math.abs(x) > Math.abs(y) && x < 0) {
        console.log('左滑')
        if (this.current < this.items.length - 1) {
          this.current += 1
        } else {
          this.current = 0
        }
      } else if (Math.abs(y) > Math.abs(x) && y > 0) {
        console.log('下滑')
      } else if (Math.abs(y) > Math.abs(x) && y < 0) {
        console.log('上滑')
      } else {
        console.log('点击')
      }
      this.swiper()
    }
  },
  destroyed () {
    clearInterval(this.timer)
  }
}
</script>

<style lang="stylus">
  #swiper
    width 100%
    overflow hidden
    position relative
    .img
      visibility hidden
    .swiper-item
      position absolute
      top 0
      width 100%
      height 100%
      transition all 0.5s ease
    .dots
      position absolute
      left 0
      right 0
      bottom 0
      height 20px
      text-align center
      .dot
        display inline-block
        width 8px
        height 8px
        border-radius 50%
        margin 0 3px
        background rgba(0,0,0,0.5)
        &.active
          background rgba(255,255,255,0.7)
    img
      width 100%
      display block
</style>
