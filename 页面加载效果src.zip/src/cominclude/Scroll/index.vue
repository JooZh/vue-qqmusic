<template>
  <div ref="wrapper" class="scroll-box">
    <slot></slot>
  </div>
</template>

<script>
import BScroll from 'better-scroll'
export default {
  props: {
    probeType: {
      type: Number,
      default: 1,
      discription: '1会非实时（屏幕滑动超过一定时间后）派发scroll 事件, 2 实时的派发 scroll 事件'
    },
    click: {
      type: Boolean,
      default: true,
      discription: '开启单击事件'
    },
    dblclick: {
      type: Boolean,
      default: true,
      discription: '开启双击事件'
    },
    tap: {
      type: Boolean,
      default: true,
      discription: '派发一个tap事件'
    },
    data: {
      type: Array,
      default: null,
      discription: '监听数据变化'
    },
    listenScroll: {
      type: Boolean,
      default: false,
      discription: '监听滚动事件'
    },
    pullup: {
      type: Boolean,
      default: false,
      discription: '监听下拉事件'
    },
    beforeScroll: {
      type: Boolean,
      default: false,
      discription: '监听到底事件'
    },
    freeScroll: {
      type: Boolean,
      default: false,
      discription: '开启横纵向滚动'
    },
    scrollY: {
      type: Boolean,
      default: false,
      discription: '开启纵向滚动'
    },
    scrollX: {
      type: Boolean,
      default: false,
      discription: '开启横向滚动'
    }
  },
  // 确保DOM已经加载了
  mounted () {
    let timer = setTimeout(() => {
      this.initScroll()
      clearTimeout(timer)
    }, 30)
  },
  methods: {
    initScroll () {
      // 判断滚动的DOM是否已经加载了
      if (!this.$refs.wrapper) {
        return
      }
      // 初始化滚动
      this.scroll = new BScroll(this.$refs.wrapper, {
        scrollY: this.scrollY,
        scrollX: this.scrollX,
        freeScroll: this.freeScroll,
        probeType: this.probeType,
        click: this.click,
        dblclick: this.dblclick
      })
      // 监听滚动事件
      if (this.listenScroll) {
        let me = this
        this.scroll.on('scroll', (pos) => {
          me.$emit('scroll', pos)
        })
      }
      // 监听下拉事件
      if (this.pullup) {
        this.scroll.on('scrollEnd', () => {
          if (this.scroll.y <= (this.scroll.maxScrollY + 50)) {
            this.$emit('scrollToEnd')
          }
        })
      }
      // 监听滚动开始之前
      if (this.beforeScroll) {
        this.scroll.on('beforeScrollStart', () => {
          this.$emit('beforeScroll')
        })
      }
    },
    enable () {
      this.scroll && this.scroll.enable()
    },
    disable () {
      this.scroll && this.scroll.disable()
    },
    refresh () {
      this.scroll && this.scroll.refresh()
    },
    scrollTo () {
      this.scroll && this.scroll.scrollTo.apply(this.scroll, arguments)
    },
    scrollToElement () {
      this.scroll && this.scroll.scrollToElement.apply(this.scroll, arguments)
    }
  },
  watch: {
    data () {
      setTimeout(() => {
        this.refresh()
      }, 20)
    }
  }
}
</script>

<style scoped lang="stylus">
  .scroll-box
    overflow: hidden;
    white-space:nowrap;
</style>
