import * as types from './types'

export default {
  togglePlayer ({ commit }) {
    commit(types.togglePlayer)
  },
  next ({ commit }) {
    commit(types.next)
  },
  prev ({ commit }) {
    commit(types.prev)
  },
  play ({ commit }) {
    commit(types.play)
  },
  pause ({ commit }) {
    commit(types.pause)
  }
}
