import * as types from './types'

export default {
  // 路由方向
  [types.UPDATE_DIRECTION] (state, payload) {
    state.direction = payload.direction
  },
  // 切换播放器状态
  [types.togglePlayer] (state) {
    // 当无播放列表的时候
    if (state.playerList.length === 0) {
      state.playStatus = false
    }
    state.playerState = !state.playerState
  },
  // 列表播放
  [types.playAll] (state, list) {
    state.playerList = list
    state.playSong = list[0]
    state.playerState = !state.playerState
    state.playSongindex = 0
  },
  // 点击播放单首
  [types.playOne] (state, song) {
    if (song.songid) {
      state.playerList.unshift(song)
      state.playSongindex = 0
      state.playSong = song
    } else {
      state.playSong = state.playerList[song]
      state.playSongindex = song
    }
  },
  // 点击添加歌曲
  [types.playAdd] (state, song) {
    state.playerList.unshift(song)
  },
  // 点击下一曲
  [types.next] (state) {
    let long = state.playerList.length - 1
    if (state.playSongindex !== long) {
      state.playSongindex += 1
    } else {
      state.playSongindex = 0
    }
    state.playSong = state.playerList[state.playSongindex]
  },
  // 点击上一曲
  [types.prev] (state) {
    if (state.playSongindex !== 0) {
      state.playSongindex -= 1
    } else {
      state.playSongindex = state.playerList.length - 1
    }
    state.playSong = state.playerList[state.playSongindex]
  },
  // 点击播放
  [types.play] (state) {
    state.playStatus = true
  },
  // 点击暂停
  [types.pause] (state) {
    state.playStatus = false
  }
}
