
export const direction = state => state.direction
export const playerState = state => state.playerState
export const playSong = state => state.playSong
export const playStatus = state => state.playStatus
export const playerList = state => state.playerList
export const playSongindex = state => state.playSongindex
