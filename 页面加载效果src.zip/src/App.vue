<template>
  <div id="app">
    <transition :name="'vux-pop-' + (direction === 'forward' ? 'in' : 'out')">
      <keep-alive exclude="no-keep">
        <router-view class="router-view" :scroll="scroll"></router-view>
      </keep-alive>
    </transition>
    <SongPlayer></SongPlayer>
    <TabBar></TabBar>
  </div>
</template>

<script>
import TabBar from '@/comlayout/TabBar/index'
import SongPlayer from '@/comlayout/SongPlayer/index'
import { mapGetters } from 'vuex'
export default {
  name: 'App',
  data () {
    return {
      scroll: 0
      // stop: false
    }
  },
  mounted () {
    document.addEventListener('scroll', this.scrollTop)
    // let m = document.querySelector('#app')
    // m.addEventListener('touchstart', this.firstPlay)
  },
  computed: {
    ...mapGetters(['direction'])
  },
  components: {
    TabBar,
    SongPlayer
  },
  methods: {
    // firstPlay () {
    //   let music = document.querySelector('#audio')
    //   music.play()
    //   if (music.src !== '') {
    //     this.stop = true
    //   }
    // },
    scrollTop () {
      this.scroll = document.documentElement.scrollTop || document.body.scrollTop
    }
  }
  // watch: {
  //   stop () {
  //     let m = document.querySelector('#app')
  //     m.removeEventListener('touchstart', this.firstPlay)
  //   }
  // }
}
</script>

<style lang="stylus" scoped>
  #app{
    width: 100%;
    height:100%;
  }
  .router-view{
    width: 100%;
    height:100%;
  }
  .vux-pop-out-enter-active,
  .vux-pop-out-leave-active,
  .vux-pop-in-enter-active,
  .vux-pop-in-leave-active {
    will-change: transform;
    transition: all 500ms;
    height: 100%;
    top: 0;
    position: absolute;
    backface-visibility: hidden;
    perspective: 1000;
  }
  .vux-pop-out-enter {
    opacity: 0;
    transform: translate3d(-100%, 0, 0);
  }
  .vux-pop-out-leave-active {
    opacity: 0;
    transform: translate3d(100%, 0, 0);
  }
  .vux-pop-in-enter {
    opacity: 0;
    transform: translate3d(100%, 0, 0);
  }
  .vux-pop-in-leave-active {
    opacity: 0;
    transform: translate3d(-100%, 0, 0);
  }
</style>
