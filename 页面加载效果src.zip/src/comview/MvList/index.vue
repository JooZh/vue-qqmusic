<template>
  <div id="mvlist" class='mvlist'>
    <div class='list' v-for="(item,index) in mvlist" :key="index">
      <div class='detail' @click='getPlay(item.vid)'>
        <img ref="img" class='img' v-lazy='{src:item.pic,error:defaultImg,loading:defaultImg}'>
        <div class="title-box">
          <div class='title'>{{item.title}}</div>
        </div>
        <div class='date'>播放：{{item.listenCount}} 万</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    mvlist: {
      type: Array
    }
  },
  data () {
    return {
      defaultImg: require('@/assets/images/mv.png')
    }
  },
  methods: {
    getPlay (vid) {

    }
  }

}
</script>

<style lang="stylus" scoped>
@import '../../assets/css/common'
#mvlist
  color:rgba(255,255,255,0.5)
  display flex
  padding 5px
  flex-wrap wrap
  .list
    flex 50% 0 0
    .detail
      padding 5px
      position relative
      .img
        width: 100%;
      .title-box
        height: 30px;
        position relative
        line-height: 30px;
      .title
        position absolute
        left 0
        right 0
        font-size: $fontS;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        word-wrap: normal;
      .date
        font-size: $fontXS

@media screen and (max-width:480px)
  .img
    height 108px
@media screen and (max-width:375px)
  .img
    height 97px
@media screen and (max-width:320px)
  .img
    height 82px

</style>
