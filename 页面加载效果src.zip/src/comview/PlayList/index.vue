<template>

  <div ref="songlist" class='songlist'>
    <ul>
      <li
        class="list"
        v-for="(item,index) in playerList"
        :class="{'del':deleteIndex==index,'active':playSongindex == index}"
        :key="index">
        <div class='number'>
          <!-- <Icon type="md-stats" /> -->
          <Icon v-if="playSongindex == index" type="md-stats" />
          <Icon v-else type="md-musical-notes" />
        </div>
        <div class='detail' @click='changeSong(index)'>
          <div class="songname">
            <div class="pix">{{item.songname}}</div>
          </div>
          <div class="albumname">
            <div class="pix">{{item.singer}} · {{item.albumname}}</div>
          </div>
        </div>
        <div class='time'>
          <div class='c' @click='deleteSong(index)'><Icon type="md-close" /></div>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import BScroll from 'better-scroll'
export default {
  data () {
    return {
      deleteIndex: -1,
      scroll: null
    }
  },
  mounted () {
    this.initScroll()
  },
  computed: {
    ...mapGetters([
      'playerList',
      'playSongindex'
    ])
  },
  watch: {
    playerList () {
      this.scroll.refresh()
    }
  },
  methods: {
    initScroll () {
      this.$nextTick(() => {
        /* eslint-disable no-new */
        this.scroll = new BScroll(this.$refs.songlist, {
          scrollY: true,
          click: true
        })
      })
    },
    clearPlayerList () {
      // this.setData({
      //   musicList: []
      // })
    },
    changeSong (e) {
      // let index = e.currentTarget.dataset.index
      // this.setData({
      //   playSongindex: index
      // }, () => {
      //   this.$emit('changeSong', {
      //     index: index
      //   })
      // })
    },
    deleteSong (e) {
      // let index = e.currentTarget.dataset.index
      // this.emit('deleteSong', {
      //   index: index
      // })
      // this.setData({
      //   deleteIndex: index
      // }, () => {
      //   let timer = setTimeout(() => {
      //     this.setData({
      //       musicList: this.data.playerList,
      //       deleteIndex: -1
      //     })
      //     clearTimeout(timer)
      //   }, 300)
      // })
    }
  }
}
</script>

<style scoped>
  .songlist{
  color: #e5e5e5;
  font-size: 14px;
  padding: 10px 0
}
.songlist .list{
  display: flex;
  /* padding: 10px 0; */
  /* height: 45px; */
  /* margin: 10px 0; */
  padding: 8px 0 0 0;
  position: relative;
}
.songlist .list.del{
  transition: all 0.3s ease;
  height: 0;
  padding: 0;
  transform: scaleY(0)
}
.songlist .list.active{
  color: #ffcd32;
  /* background: rgba(255,205,50,0.2); */
}
.songlist .list.active .detail .albumname{
  color: #aaa;
}
.songlist .list.active .time .c{
  color: #ffcd32;
}
.songlist .list .number{
  flex: 0 0 50px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 16px
}
.songlist .list .detail{
  flex: 1;
}
.songlist .list .detail .songname{
  position: relative;
  font-size: 14px;
  line-height: 25px;
  height: 25px;
}
.songlist .list .detail .fix{
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  word-wrap: normal;
}
.songlist .list .detail .albumname{
  position: relative;
  font-size: 12px;
  line-height: 15px;
  height: 20px;
  color: #888;
}
.songlist .list .time{
  font-size: 12px;
  flex: 0 0 50px;
  display: flex;
  justify-content: center;
  align-items: center;
}
.songlist .list .time .c{
  /* border-radius: 50%; */
  width: 20px;
  height: 20px;
  text-align: center;
  line-height: 18px;
  /* border: 1px solid #ccc; */
  color: #ccc;
  font-size: 20px;
}
</style>
